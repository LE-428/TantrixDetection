# Tantrix > 2025-07-25 2:32pm
https://universe.roboflow.com/peter-silie-fedac/tantrix-2xynd

Provided by a Roboflow user
License: CC BY 4.0

